#imports
from bs4 import BeautifulSoup
import requests
import boto3
import json
import math
import random
import string
from fake_useragent import UserAgent

#random string generator for partition keys
def id_generator(size=12, chars=string.ascii_uppercase + string.digits):
  return ''.join(random.choice(chars) for _ in range(size))

#UserAgent to generate random UserAgents for the header
uaHeaders = UserAgent()

#chrome agent, need this to avoid 403 error when using requests
headers = {'User-Agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36'}

#lambda client that will actually push the data into the kinesis stream
lambda_client = boto3.client('lambda')

#converts extracted date to SQL date format
def convertDate(date):
    monthDict = {
        'Jan':'01',
        'Feb':'02',
        'Mar':'03',
        'Apr':'04',
        'May':'05',
        'Jun':'06',
        'Jul':'07',
        'Aug':'08',
        'Sep':'09',
        'Oct':'10',
        'Nov':'11',
        'Dec':'12'
    }
    month = monthDict[date[:3]]
    year = date[-4:]
    day = date[4:-6]
    if len(day) < 2:
        day = '0' + day
    sqlDate = year + '-' + month + '-' + day
    return sqlDate

#date conversion to SQL for Chrome edge case dates
def convertEdgeDate(date):
    year = date[:4]
    month = date[6:8]
    day = date[9:]
    if len(day) < 2:
        day = '0' + day
    sqlDate = year + '-' + month + '-' + day
    return sqlDate

#scrape review info, put it in a dict, stringify it and send it to
#a lambda function that sends it to a kinesis data stream
def handler(event, context):
  site_url = event['site_url']
  page = requests.get(site_url, headers={'user-agent':uaHeaders.random})
  print(page.status_code)
  print(site_url)

  #manual limitation on number of review pages to scrape
  pageLimit = 80
  pageCount = 1

  #number of pages to gather reviews from before sending the data to the next lambda function
  gatherPageLimit = 40
  gatherPageCount = 1

  #List of records to send to the next lambda function
  recordList = []

  #count of records in recordList
  recordCount = 0

  #get soup
  soup = BeautifulSoup(page.content, 'html.parser')

  #grab number of reviews to get max page limit
  reviewCountSoup = soup.find('div', {'class':'common__EIReviewSortBarStyles__sortsHeader'})
  reviewCount = int(reviewCountSoup.find('strong').getText())
  maxPageLimit = int(math.ceil(reviewCount/10))

  #grab company name
  companyNameSoup = soup.find('p', {'class':'h1 strong tightAll'})
  companyName = companyNameSoup['data-company']

  while pageCount <= pageLimit and pageCount <= maxPageLimit:
      print('page ' + str(pageCount))

      test = soup.find_all('li', {'class':'empReview cf'})
      for subtest in test:

          #grab review ID
          empRevID = subtest['id'][10:]

          #grab review timestamp
          revDateSoup = subtest.find('time', {'class':'date subtle small'})
          if revDateSoup != None:
              revDate = convertDate(revDateSoup.getText())
          #edge case where "featured review" shows up instead of date, need to grab date from the review-specific page
          else:
              thisReviewLink = subtest.find('a', {'class':'reviewLink'})['href']
              subPage = requests.get('https://www.glassdoor.com' + thisReviewLink, headers={'user-agent':uaHeaders.random})
              subSoup = BeautifulSoup(subPage.content, 'html.parser')
              revDateSubSoup = subSoup.find('time', {'class':'date subtle small'})
              print(revDateSubSoup)
              revDate = convertEdgeDate(revDateSubSoup.getText())
              print(revDate)

          #grab reviewer employment status (current or former)
          revEmpStatus = subtest.find('span', {'class':'authorJobTitle middle reviewer'}).getText()
          if revEmpStatus[0] == 'C':
              revEmpStatus = revEmpStatus[:7]
          else:
              revEmpStatus = revEmpStatus[:6]

          #grab overall rating
          overRating = subtest.find('span', {'class':'value-title'})['title']

          #grab subreviews, make dictionary for reviews that have all subratings submitted
          subratings = subtest.find_all('span', {'class':'gdBars gdRatings med'})
          if len(subratings) == 5:
              sr = []
              for sub in subratings:
                  sr.append(sub['title'])
              resultsDict = {
                  'company':companyName,
                  'id':empRevID,
                  'postdate':revDate,
                  'overallrating':overRating,
                  'employeestatus':revEmpStatus,
                  'worklifebalance':sr[0],
                  'cultureandvalues':sr[1],
                  'careeropportunities':sr[2],
                  'compensationandbenefits':sr[3],
                  'seniormanagement':sr[4]
                  }
              #create record with resultsDict and append to recordList
              newRecord = {"Data": json.dumps(resultsDict), "PartitionKey": id_generator()}
              recordList.append(newRecord)
              recordCount += 1

      #check if recordList is ready to be sent to next lambda function
      if gatherPageCount >= gatherPageLimit:
        #output to kinesis here
        try:
            invoke_response = lambda_client.invoke(
              FunctionName='KinesisOutputFunction',
              InvocationType='Event',
              Payload=json.dumps(recordList)
            )
            print(str(recordCount) + ' records sent')
            print(json.dumps(recordList))
            #reset gatherPageCount and empty recordList
            gatherPageCount = 1
            del recordList[:]
            recordCount = 0
        except:
            print("Error while invoking KinesisOutputFunction")
      else:
        gatherPageCount += 1

      pageCount += 1
      next_url = site_url[:-4] + '_P' + str(pageCount) + '.htm'
      try:
        page = requests.get(next_url, headers={'user-agent':uaHeaders.random})
      except:
        print('Error loading page: ' + next_url)
      print(page.status_code)
      print(next_url)
      soup = BeautifulSoup(page.content, 'html.parser')

  #send rest of data in recordList if it's not empty
  if recordList:
    #output to kinesis here
    try:
        invoke_response = lambda_client.invoke(
          FunctionName='KinesisOutputFunction',
          InvocationType='Event',
          Payload=json.dumps(recordList)
        )
        print(str(recordCount) + ' records sent')
        print(json.dumps(recordList))
    except:
        print("Error while invoking KinesisOutputFunction")


