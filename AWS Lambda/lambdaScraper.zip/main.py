#imports
from bs4 import BeautifulSoup
import requests
import boto3
import json

#chrome agent, need this to avoid 403 error when using requests
headers = {'User-Agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36'}

#lambda client that will actually push the data into the kinesis stream
lambda_client = boto3.client('lambda')

#scrape review info, put it in a dict, stringify it and send it to
#a lambda function that sends it to a kinesis data stream
def handler(event, context):
  site_url = event['site_url']
  page = requests.get(site_url, headers=headers)
  print(page.status_code)

  #get soup
  soup = BeautifulSoup(page.content, 'html.parser')

  test = soup.find_all('div', {'class':'subRatings module stars__StarsStyles__subRatings'})
  for subtest in test:
      subratings = subtest.find_all('span', {'class':'gdBars gdRatings med'})
      #only process reviews that have submitted all 5 subratings
      if len(subratings) == 5:
          companyNameSoup = soup.find('p', {'class':'h1 strong tightAll'})
          companyName = companyNameSoup['data-company']
          sr = []
          #add subratings into a list to organize them in a dict
          for sub in subratings:
              sr.append(sub['title'])
          resultsDict = {
              'Company':companyName,
              'Work/Life Balance':sr[0],
              'Culture & Values':sr[1],
              'Career Opportunities':sr[2],
              'Compensation and Benefits':sr[3],
              'Senior Management':sr[4]
              }
          #output to kinesis here
          #print(json.dumps(resultsDict))
          invoke_response = lambda_client.invoke(
            FunctionName='KinesisOutputFunction',
            InvocationType='Event',
            Payload=json.dumps(resultsDict)
          )
          invoke_response['Payload'].read()
