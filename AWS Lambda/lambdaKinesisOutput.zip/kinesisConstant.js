module.exports = {
  STATE: {
    ACTIVE: 'ACTIVE',
    UPDATING: 'UPDATING',
    CREATING: 'CREATING',
    DELETING: 'DELETING'
  },
  STREAM_NAME: 'ReviewStream',
  PARTITION_KEY: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
  PAYLOAD_TYPE: 'String',
  REGION: 'us-east-1',
  API_VERSION: '2013-12-02'
}

